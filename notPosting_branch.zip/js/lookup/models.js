// No separate models needed in this split; API responses are used directly.
